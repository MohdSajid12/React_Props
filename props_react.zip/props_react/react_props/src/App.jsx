
import { useState } from 'react';
import './App.css'
import Button from './components/Button';
import Card from './components/Card'

//now button this is parent
//how we can pass function via props
function App()
{

    const [count ,setCount] = useState(0);

    //when this function will click count will increase by 1
   function handleClick()
   {
      setCount(count+1);   
   }

   return (
     <div>
      {/* we can also use different name no isse  */}
      <Button handleClick={handleClick} text="Click me">  
         <h1>{count}</h1>
      </Button>
      {/* <Card name="sajid shaikh">
       <h1>Hello this is the h1</h1>
       <h2>Hello this is the h2</h2>
       <p>Hello this is the paragraph</p>
      </Card>
      <Card children="me ek children hu">
       
      </Card> */}
     </div>
   )
}

export default App;
