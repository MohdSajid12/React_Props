import React from 'react';

//we want to give this handle which will handle but this not have handler parent have the hndler
//in this app is parent because we have used in parent and button is a child
function Button(props)
{
   return (
      <div>
         {props.children}
         <button onClick={props.handleClick}>{props.text}</button>
      </div>
   )
}

export default Button


//we have passed the function in button and we have access the child in that function